package Persistencia;

public class Agente {

	protected int mBD;
	protected int $Instancia;

	protected Agente() {
		// TODO - implement Agente.Agente
		throw new UnsupportedOperationException();
	}

	public void insert() {
		// TODO - implement Agente.insert
		throw new UnsupportedOperationException();
	}

	public void delete() {
		// TODO - implement Agente.delete
		throw new UnsupportedOperationException();
	}

	public void upgrade() {
		// TODO - implement Agente.upgrade
		throw new UnsupportedOperationException();
	}

	public void select() {
		// TODO - implement Agente.select
		throw new UnsupportedOperationException();
	}

	public void get_agente() {
		// TODO - implement Agente.get_agente
		throw new UnsupportedOperationException();
	}

}