package Domain;

public class control_enfermedad {

	public void addEnfermedad() {
		// TODO - implement control_enfermedad.addEnfermedad
		throw new UnsupportedOperationException();
	}

	public void removeEnfermedad() {
		// TODO - implement control_enfermedad.removeEnfermedad
		throw new UnsupportedOperationException();
	}

	public void viewEnfermedad() {
		// TODO - implement control_enfermedad.viewEnfermedad
		throw new UnsupportedOperationException();
	}

}