package Domain;

public class Enfermedad {

	private String nombre;
	private String sintoma;
	private String temporalidad;
	private String medicinas_regional;
	private String medicinas_nacional;
	private boolean confinamiento;

}