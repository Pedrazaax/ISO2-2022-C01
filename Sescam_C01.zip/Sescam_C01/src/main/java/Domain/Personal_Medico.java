package Domain;

public class Personal_Medico {

	private Enfermedad lista_Enfermedades;

	public void addEnfermedad() {
		// TODO - implement Personal_Medico.addEnfermedad
		throw new UnsupportedOperationException();
	}

	public void removeEnfermedad() {
		// TODO - implement Personal_Medico.removeEnfermedad
		throw new UnsupportedOperationException();
	}

	public void viewEnfermedad() {
		// TODO - implement Personal_Medico.viewEnfermedad
		throw new UnsupportedOperationException();
	}

}