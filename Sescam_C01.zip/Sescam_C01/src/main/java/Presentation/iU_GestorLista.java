package Presentation;

public class iU_GestorLista {

	public void submitEnfermedad() {
		// TODO - implement iU_GestorLista.submitEnfermedad
		throw new UnsupportedOperationException();
	}

}