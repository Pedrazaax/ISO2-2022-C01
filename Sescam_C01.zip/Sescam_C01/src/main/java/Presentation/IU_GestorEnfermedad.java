package Presentation;

public class IU_GestorEnfermedad {

	public void submitAltaEnfermedad() {
		// TODO - implement IU_GestorEnfermedad.submitAltaEnfermedad
		throw new UnsupportedOperationException();
	}

	public void submitBajaEnfermedad() {
		// TODO - implement IU_GestorEnfermedad.submitBajaEnfermedad
		throw new UnsupportedOperationException();
	}

}